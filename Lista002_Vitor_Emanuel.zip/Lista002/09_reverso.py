#9. Leia uma frase pelo teclado e a imprima ao contrário. Por exemplo, se a frase for "Manjo muito de
#Python!", a saída deverá ser '!nohtyP ed otium ojnaM'.

print("Escreva uma frase:")
frase = input()

frase_reversa = frase[::-1]

print(frase_reversa)