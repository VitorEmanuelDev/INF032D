#1. Crie uma lista com o nome das 3 pessoas mais próximas.

pessoas = ["Darth Vader", "Obi-Wan Kenobi", "Yoda"]

print(pessoas)