numero = int(input("Informe um numero:"))

if 20 < numero < 90:
    print("Esta contido no intervalo entre 20 e 90")
else:
    print("Nao esta contido:")