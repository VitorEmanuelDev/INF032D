#3. Crie um dicionário vazio filmes = {}. Utilize o nome de um filme como chave. E, como valor,
#outro dicionário contendo o vilão e o ano em que o filme foi lançado. Preencha 5 filmes.

filmes = {"The Queen's Gambit": {"Vasily Borgov": 2020},
          "The Mandalorian": {"Moff Gideon": 2020},
          "John Wick": {"Viggo Tarasov": 2014},
          "The Manchurian Candidate": {"Raymond Shaw": 2004},
          "Rick and Morty": {"Birdperson": 2013}

          }

print(filmes)