#4. Crie um dicionário d e coloque nele seus dados: nome, idade, telefone, endereço. Usando o
#dicionário d criado anteriormente, imprima seu nome.

pessoa = {'nome': 'Vitor Emanuel', 'idade': 32, 'telefone': 000000000,
'endereço': 'rua xxxxxx'}

print(pessoa['nome'])