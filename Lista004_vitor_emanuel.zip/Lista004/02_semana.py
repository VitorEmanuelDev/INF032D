#2. Crie um dicionário vazio semana = {} e o complete com uma chave para cada dia da semana,
#tendo como seu valor uma lista com as aulas que você tem nesse dia (sábado e domingo
#recebem listas vazias, ou você tem aula?).

semana = {
    "Segunda": ["Ciencia de Dados com Python"],
    "Terça": ["Programação Python"],
    "Quarta": ["Ciencia de Dados com Python"],
    "Quinta": ["Programação Python"],
    "Sexta": ["Aula particular"],
    "Sábado": ["Aula particular"]
}

print(semana)